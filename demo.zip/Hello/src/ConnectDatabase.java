import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.Statement;

public class ConnectDatabase {
public static void main(String[] args) {
	Connection con = null;
	try { 	
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?user=root&password=1234");
		Statement mysql =(Statement) con.createStatement();
		ResultSet myrs = mysql.executeQuery("SELECT *FROM EMP ");
		while (myrs.next()) {
			System.out.println(myrs.getString("ename"));
			
		}
	}catch(Exception e) {
		e.printStackTrace();
	}

}

}
