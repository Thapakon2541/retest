import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class StatementSQL {
	public static Connection getConnection() {
		Connection con = null;
		try { 	
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ticket?user=root&password=1234");
			Statement mysql =(Statement) con.createStatement();
//			ResultSet myrs = mysql.executeQuery("SELECT *FROM EMP ");
//			while (myrs.next()) {
//				System.out.println(myrs.getString("ename"));
//				
//			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	public static void inserEmployee(int amount ,String category) {
		 	// 1. open Connection
		     	Connection connection = getConnection();
		     	String sqlInsert = "insert into ticket(id,amount,category) values(?,?,?)";
		     	PreparedStatement pstInsert = null;
			// 2.Create Statement // Create SQL // // 3.เตรียม Statement ใส่ข้อมูล
		     	try {
		     		pstInsert = (PreparedStatement) connection.prepareStatement(sqlInsert);
	
		     		pstInsert.setInt(1, 2);
		     		pstInsert.setInt(2, amount);
		     		pstInsert.setString(3, category);
					int result = pstInsert.executeUpdate();
					
				} catch (Exception e) {
					e.printStackTrace();
					// TODO: handle exception
				}finally {
					try {
						if (pstInsert !=null) {
							pstInsert.close();
						}
					} catch (Exception e) {
						e.printStackTrace();                    // ปิด Resource
						// TODO: handle exception
					}
					try {
						if (connection != null) {
							connection.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
						// TODO: handle exception
					}
				}

	}
	  static void getTicket() {
		  Connection connection = getConnection(); // connect DB เตรียมคำสั่งสั่ง SQL
		  String sqlString = "SELECT * FROM TICKET";
		  Statement st = null;
		  ResultSet rSet = null;
		 
		  try {
			 st = (Statement) connection.createStatement();
			 rSet = st.executeQuery(sqlString);
			 while (rSet.next()) {
				 System.out.println(rSet.getString("amount")+"    "+rSet.getString("category"));
				
				 
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			try {
				if (rSet != null) {
					rSet.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			try {
				if(connection != null) {
					connection.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				// TODO: handle exception
			}
		}
		  
		

	}
	 static void updateTicket() {
		Connection connection = getConnection();
		String sql= "update ticket"
				+ " SET amount = ? ,category =? "
				+ "Where id = ?";
		PreparedStatement pr=null;
		try { 	
			pr = (PreparedStatement) connection.prepareStatement(sql);
			pr.setInt(1, 1000);
			pr.setString(2, "Product");
			pr.setInt(3,0);
			int rs = pr.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			try {
				if (pr!=null) {
					pr.close();
					
				}
			} catch (Exception e) {

				e.printStackTrace();
				// TODO: handle exception
			}
			try {
				if (connection != null) {
					connection.close();
					
				}
			} catch (Exception e) {
				e.printStackTrace();
				// TODO: handle exception
			}
		}

	}
	  static void deleteTicket(int id) {
		  Connection connection = getConnection();
		  String sql= "DELETE FROM TICKET WHERE id = ? ";
		  PreparedStatement  pr=null;
		  
		 try {
			pr = (PreparedStatement) connection.prepareStatement(sql);
			pr.setInt(1,id);
			int rs = pr.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}finally {
			try {
				if (pr != null) {
					pr.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				// TODO: handle exception
			}
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e2) {
					e2.printStackTrace();
				// TODO: handle exception
			}
		}

	}
	  
	public static void main(String[] args) {
//		getConnection();
		inserEmployee(1000,"traval2");
		//updateTicket();
//		deleteTicket(29);
		getTicket();
		
	}

}
