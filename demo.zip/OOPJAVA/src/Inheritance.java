
public class Inheritance {
	class Calculation{
		int z;
		
		public void addtion(int n , int x) {
			System.out.println("จำนวนของ giben number"+ z);
		}
		public void subtraction(int x , int y) {
			z=x=y;
			

		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
