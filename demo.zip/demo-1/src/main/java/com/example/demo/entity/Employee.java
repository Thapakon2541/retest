package com.example.demo.entity;


import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="employee")
@Getter
@Setter
@ToString
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class Employee {

	
	@Id
	@GeneratedValue
	private Long id_employee;
	public Long getId_employee() {
		return id_employee;
	}
	public void setId_employee(Long id_employee) {
		this.id_employee = id_employee;
	}

	public String getEmployee_no() {
		return employee_no;
	}
	public void setEmployee_no(String employee_no) {
		this.employee_no = employee_no;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	private String employee_no;
	private String firstname;
	private String lastname;
	private Long  employee_has_sidework_historyLong;
	private Long emoployee_id;
	private Long work_type;
	public Long getEmployee_has_sidework_historyLong() {
		return employee_has_sidework_historyLong;
	}
	public void setEmployee_has_sidework_historyLong(Long employee_has_sidework_historyLong) {
		this.employee_has_sidework_historyLong = employee_has_sidework_historyLong;
	}
	public Long getEmoployee_id() {
		return emoployee_id;
	}
	public void setEmoployee_id(Long emoployee_id) {
		this.emoployee_id = emoployee_id;
	}
	public Long getWork_type() {
		return work_type;
	}
	public void setWork_type(Long work_type) {
		this.work_type = work_type;
	}

	
	
	}
	
