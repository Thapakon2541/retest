package com.example.demo.entity;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class WorkType {
	@Id
	@GeneratedValue
    private Long id_work_type;
    public Long getId_work_type() {
		return id_work_type;
	}
	public void setId_work_type(Long id_work_type) {
		this.id_work_type = id_work_type;
	}
	public String getWork_type_name() {
		return work_type_name;
	}
	public void setWork_type_name(String work_type_name) {
		this.work_type_name = work_type_name;
	}
	private String work_type_name;	
}
