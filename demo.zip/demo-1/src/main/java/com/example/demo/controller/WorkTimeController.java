package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.WorkTimeDao;
import com.example.demo.entity.Employee;


@RestController
public class WorkTimeController {
	@Autowired 
	private WorkTimeDao wtk;
	
	@GetMapping(path = "/employee/{id}")
	public List<Employee> getEmployee(@PathVariable(value = "id")Long id) {
			return wtk.findAllByType(id);
	}
	
}
