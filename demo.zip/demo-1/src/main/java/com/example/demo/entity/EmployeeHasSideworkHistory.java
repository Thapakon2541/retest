package com.example.demo.entity;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Embeddable

public class EmployeeHasSideworkHistory {
	@Id
	@GeneratedValue
	private Long employee_has_sidework_history_id;
	public Long getEmployee_has_sidework_history_id() {
		return employee_has_sidework_history_id;
	}
	public void setEmployee_has_sidework_history_id(Long employee_has_sidework_history_id) {
		this.employee_has_sidework_history_id = employee_has_sidework_history_id;
	}
	public Long getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(Long employee_id) {
		this.employee_id = employee_id;
	}
	public Long getWork_type() {
		return work_type;
	}
	public void setWork_type(Long work_type) {
		this.work_type = work_type;
	}
	private Long employee_id;
	private Long work_type;

}
