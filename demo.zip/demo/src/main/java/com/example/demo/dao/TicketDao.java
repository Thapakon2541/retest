package com.example.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Ticket;

public interface TicketDao extends JpaRepository  <Ticket,Integer>  {

	
	@Bean
	@Query(value = "SELECT * FROM TICKET WHERE ID = :id",nativeQuery = true)
	List<Ticket> findAllById(@Param(value = "id")int id  );
	@Bean
	@Query(value = "SELECT * FROM TICKET WHERE category = :category",nativeQuery = true)
	List<Ticket> findAllByCategory(@Param(value ="category" )String category);
	@Transactional
	List<Ticket> deleteAllById(int id);
	@Query(value = "select  * from ticket.student s inner join ticket.department d on d.DepartmentId = s.departmentid where s.departmentid =:id",nativeQuery = true)
	List<Ticket> findAllByDeparment(@Param(value = "id")int id);
	
	
	


	
	 	

} 