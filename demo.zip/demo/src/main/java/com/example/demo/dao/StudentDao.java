package com.example.demo.dao;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;

import com.example.demo.model.Student; 

public interface StudentDao extends JpaRepository <Student, Integer> {
	@Bean
	@Query(value = "select  * from "
			+ "ticket.student s "
			+ "inner join ticket.department d "
			+ "on d.DepartmentId = s.departmentid "
			+ "where s.departmentid =:id",nativeQuery = true)
	List<Student> findAllByDeparment(@Param(value = "id")int id);
}