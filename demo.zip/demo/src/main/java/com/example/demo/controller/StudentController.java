package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.StudentDao;
import com.example.demo.model.Student;



@RestController
@RequestMapping("/students")
public class StudentController {
	 @Autowired
	   private StudentDao std;
	 
	   @GetMapping(path = "/{id}")
	   public List<Student> getTicketsByStden(@PathVariable(value = "id") int id){
		   
		    return  std.findAllByDeparment(id);
	   } 
	   
	   public List<Student> getStudents(){
		   
		   	return null;
		   
	   }
}




