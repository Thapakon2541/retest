package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.dao.TicketDao;
import com.example.demo.model.Ticket;



@RestController
@RequestMapping("/ticket")
public class TicketController  {
	
   @Autowired
   private TicketDao dao;
   
   @PostMapping("/bookTickets")
   public String bookTicket (@RequestBody List<Ticket> tickets) {
	   dao.saveAll(tickets);	
	return "Ticket Booked :" + tickets.size(); 
	
   }
   
   @GetMapping(path = "/student/{id}")
   public List<Ticket> getTicketsByStden(@PathVariable(value = "id") int id){
	    return  dao.findAllByDeparment(id);
   } 
   
   	
   
   @GetMapping("/getTickets")
   public List<Ticket>  getTickets(){
	
		return   (List<Ticket>) dao.findAll();
	
   }
   @GetMapping(path = "/{id}")
   public List<Ticket> getTicketsById(@PathVariable(value = "id") int id){
	    return  dao.findAllById(id);
   } 
   
   @GetMapping(path = "/category/{category}")
   public List<Ticket> getTicketsByName(@PathVariable(value = "category") String category){
	    return  dao.findAllByCategory(category);
   }
   
   @DeleteMapping("/deleteById/{id}")
   public List<Ticket>  deleteTicketById(@PathVariable int id) {
	   return  dao.deleteAllById(id);
   }
 
   
} 
